// El mensaje secreto
const secretMessage = "Te amo más que a nada en este mundo.";
let attempts = 0;

function checkGuess() {
  // Obtener lo que el usuario escribió
  const userGuess = document.getElementById('user-guess').value.trim().toLowerCase();
  const feedbackElement = document.getElementById('feedback');
  const attemptsElement = document.getElementById('attempts');

  // Verificar si el intento es válido
  if (userGuess === '') {
    feedbackElement.innerText = 'Por favor, ingresa una respuesta.';
    return;
  }

  // Aumentar el contador de intentos
  attempts++;

  // Verificar si el mensaje es correcto
  if (userGuess === secretMessage.toLowerCase()) {
    feedbackElement.innerText = `¡Correcto! El mensaje es: "${secretMessage}".
    ¡Te amo muchísimo! Has adivinado en ${attempts} intentos.`;
    attemptsElement.innerText = '';
  } else {
    feedbackElement.innerText = '¡No es el mensaje! Intenta otra vez.';
    attemptsElement.innerText = `Intentos: ${attempts}`;
  }

  // Limpiar el campo de entrada después de cada intento
  document.getElementById('user-guess').value = '';
}